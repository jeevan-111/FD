#include "stm32f4xx.h"
#define PERIOD 1000
#include"periodictimer.h"
void delayMs(int n);
 int main(void)
{
	 periodictimer();
}
